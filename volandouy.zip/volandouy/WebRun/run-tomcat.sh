#!/usr/bin/env bash
set -e

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

export CATALINA_HOME="$BASE_DIR/apache-tomcat-10.1.36"
export CATALINA_BASE="$CATALINA_HOME"

# Java portable si está
if [[ -x "$BASE_DIR/jdk-17/bin/java" ]]; then
  export JAVA_HOME="$BASE_DIR/jdk-17"
  export JRE_HOME="$JAVA_HOME"
  export PATH="$JAVA_HOME/bin:$PATH"
  echo "Usando Java portable: $JAVA_HOME"
else
  echo "Usando Java del sistema..."
fi

echo "CATALINA_HOME=$CATALINA_HOME"
echo "JAVA_HOME=$JAVA_HOME"

"$CATALINA_HOME/bin/catalina.sh" run
