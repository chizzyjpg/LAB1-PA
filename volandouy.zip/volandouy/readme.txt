UBICACION DE ESTA CARPETA TANTO PARA WEB COMO PARA SERVIDOR CENTRAL POR LOS .properties

Win: C:\Users\<usuario>\volandouy\servidor.properties

Lx: /home/<usuario>/volandouy/servidor.properties

Las otras carpetas (ServidorRun y WebRun) utilizan rutas relativas y se pueden ejecutar desde cualquier lado

los .properties se deben editar segun la ip de la pc a correr


